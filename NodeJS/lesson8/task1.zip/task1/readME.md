Создание, инициализация сервера для работы с MySQL

1. npm init -y
2. type module
3. npm i express dotenv sequelize sequelize-cli mysql2
4. npx sequelize-cli init
5. настройка config.js, ставим пароль от подключения, создаем базу данных в самом mySQL
6. создаем express сервер
